package Project4;

// simple location structure
// to encapsulate player locations
public class Location
{
  public int x;
  public int y;
  
  public Location(int xLoc, int yLoc)
  {
    x = xLoc;
    y = yLoc;
  }
}
